(() => {
  "use strict";

  const identities = [
    "404号住户", "未登记访客", "临时管理员", "夜班保安", "房东的第二把钥匙",
    "没有搬走的前住户", "走错楼层的人", "07号住户", "只在雨天值班的人"
  ];

  const state = {
    stage: "landing",
    count: 1,
    players: ["404号住户"],
    firstRule: "",
    secondRule: "",
    firstChoice: "",
    finalChoice: "",
    finalNote: "",
    tab: "text",
    sound: false,
    audio: null,
    saved: false,
    loading: false,
    error: "",
    result: null,
    archive: null,
    opening: null,
    sessionId: null,
    stateToken: null,
    aiMode: "unknown",
    cloudMode: "unknown",
    service: { deepseek: false, cloud: false },
    legacyCount: Number(localStorage.getItem("thirteenth-sentence:legacy-count") || 0),
    localLegacy: loadLegacy(),
    reuseAllowed: true,
    sourceArchiveSlug: null,
    shareSlug: null,
    viewingSharedArchive: false
  };

  const app = document.getElementById("app");
  const scene = document.getElementById("scene");
  const archiveStatus = document.getElementById("archiveStatus");
  const footerStatus = document.getElementById("footerStatus");
  const serviceDot = document.getElementById("serviceDot");
  document.getElementById("brandButton").onclick = () => {
    state.stage = "landing";
    state.viewingSharedArchive = false;
    state.sourceArchiveSlug = null;
    render();
  };
  document.getElementById("soundButton").onclick = toggleSound;

  function esc(value) {
    return String(value || "").replace(/[&<>'"]/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    }[ch]));
  }

  function loadLegacy() {
    try { return JSON.parse(localStorage.getItem("thirteenth-sentence:local-legacy") || "[]"); }
    catch { return []; }
  }

  function randomIdentity(excluded) {
    const pool = identities.filter((item) => !excluded.includes(item));
    return pool[Math.floor(Math.random() * pool.length)] || identities[0];
  }

  function setCount(count) {
    state.count = count;
    state.players = [];
    while (state.players.length < count) state.players.push(randomIdentity(state.players));
    render();
  }

  function owner(which) {
    if (which === 0) return state.players[0] || identities[0];
    if (which === 1) return state.players[Math.min(1, state.players.length - 1)] || identities[0];
    return state.players[Math.min(2, state.players.length - 1)] || identities[0];
  }

  function toggleSound() {
    state.sound = !state.sound;
    const button = document.getElementById("soundButton");
    button.className = state.sound ? "sound on" : "sound";
    button.querySelector("span").textContent = state.sound ? "环境声已开" : "开启环境声";
    if (state.sound) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (Ctx) {
        const ctx = new Ctx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = 46;
        gain.gain.value = 0.012;
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        state.audio = { ctx, osc };
      }
    } else if (state.audio) {
      state.audio.osc.stop();
      state.audio.ctx.close();
      state.audio = null;
    }
  }

  function serviceLabel() {
    if (state.service.deepseek && state.service.cloud) return "动态导演与云端档案已连接";
    if (state.service.deepseek) return "动态导演已连接 · 云端待配置";
    return "本地导演可用 · 等待服务端密钥";
  }

  async function checkServices() {
    try {
      const [healthResponse, archiveResponse] = await Promise.all([
        fetch("/api/health", { cache: "no-store" }),
        fetch("/api/archives", { cache: "no-store" })
      ]);
      if (healthResponse.ok) {
        const health = await healthResponse.json();
        state.service = { deepseek: Boolean(health.deepseek), cloud: Boolean(health.cloud) };
      }
      if (archiveResponse.ok) {
        const stats = await archiveResponse.json();
        state.legacyCount = Number(stats.legacyCount || state.localLegacy.length || 0);
        localStorage.setItem("thirteenth-sentence:legacy-count", String(state.legacyCount));
      }
    } catch {
      state.service = { deepseek: false, cloud: false };
    }
    updateChrome();
  }

  async function maybeOpenSharedArchive() {
    const pathMatch = location.pathname.match(/^\/archive\/([^/]+)$/);
    const querySlug = new URLSearchParams(location.search).get("archive");
    const slug = pathMatch?.[1] || querySlug;
    if (!slug) return;
    showLoading("正在从封存库调取这份档案……");
    try {
      const response = await fetch(`/api/archives?slug=${encodeURIComponent(slug)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "没有找到这份档案。");
      state.archive = data.archive;
      state.shareSlug = slug;
      state.sourceArchiveSlug = slug;
      state.viewingSharedArchive = true;
      state.stage = "archive";
    } catch (error) {
      state.error = error.message;
      state.stage = "landing";
    } finally {
      hideLoading();
      render();
    }
  }

  function updateChrome() {
    app.className = `game-root stage-${state.stage}`;
    archiveStatus.textContent = state.stage === "landing"
      ? ""
      : `档案 ${state.archive?.archiveId || state.opening?.archiveId || "YX-013"}`;
    footerStatus.textContent = serviceLabel();
    serviceDot.className = `service-dot ${state.service.deepseek ? "ai-ready" : "local"} ${state.service.cloud ? "cloud-ready" : ""}`;
    serviceDot.title = serviceLabel();
  }

  function resetRuntime() {
    state.firstRule = "";
    state.secondRule = "";
    state.firstChoice = "";
    state.finalChoice = "";
    state.finalNote = "";
    state.result = null;
    state.archive = null;
    state.opening = null;
    state.sessionId = null;
    state.stateToken = null;
    state.shareSlug = null;
    state.saved = false;
    state.tab = "text";
    state.error = "";
    state.viewingSharedArchive = false;
  }

  async function begin(sourceArchiveSlug = null) {
    resetRuntime();
    state.sourceArchiveSlug = sourceArchiveSlug;
    showLoading(sourceArchiveSlug ? "正在沿着旧档案恢复新的分支……" : "正在为本局建立隐藏真相……");
    try {
      const response = await fetch("/api/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerCount: state.count,
          reuseAllowed: state.reuseAllowed,
          sourceArchiveSlug
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "档案馆暂时无法开局。");
      if (!data.stateToken && data.cloudMode === "local-only") {
        throw new Error("SERVER_LOCAL_ONLY");
      }
      state.sessionId = data.sessionId;
      state.stateToken = data.stateToken || null;
      state.players = data.identities || state.players;
      state.opening = data.opening;
      state.aiMode = data.aiMode;
      state.cloudMode = data.cloudMode;
      state.legacyCount = Number(data.legacyCount ?? state.legacyCount);
    } catch (error) {
      console.warn("Server session unavailable, local director used", error);
      state.sessionId = null;
      state.stateToken = null;
      state.aiMode = "local";
      state.cloudMode = "local";
      state.opening = localOpening();
      const localPlayers = [];
      while (localPlayers.length < state.count) localPlayers.push(randomIdentity(localPlayers));
      localPlayers[0] = state.opening.primaryIdentity;
      state.players = localPlayers;
    } finally {
      hideLoading();
      state.stage = "briefing";
      render();
    }
  }

  function localOpening() {
    const inherited = state.localLegacy[0]?.quote || "本楼没有十四层。";
    return {
      archiveId: "YX-013",
      title: "《雨巷十三号住户须知》",
      primaryIdentity: "404号住户",
      briefing: "入住登记显示，你住在四楼最里面的房间。但本楼的门牌编号从403直接跳到了405。",
      inheritedFragment: inherited,
      firstTask: {
        title: "写下一条夜间规定",
        instruction: "请写一条关于夜间敲门声的规定。它表面上应该保护住户，但最好让人无法确定究竟该开门，还是绝对不能开门。",
        constraints: ["包含一个具体时间或次数", "不要直接写明门外是什么", "给住户一个明确动作"],
        hints: ["凌晨2:13", "猫眼", "邻居的声音", "四次敲门", "门内"],
        placeholder: "当你在……听见……时，请……"
      }
    };
  }

  async function callDirector(action, payload) {
    showLoading(action === "finalize" ? "正在核验每条规则能否被真相解释……" : "档案正在回应你写下的内容……");
    try {
      if (!state.sessionId && !state.stateToken) return localDirector(action, payload);
      const response = await fetch("/api/director", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action,
          sessionId: state.sessionId,
          stateToken: state.stateToken,
          ...payload
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "档案暂时无法继续。");
      state.stateToken = data.stateToken || state.stateToken;
      state.aiMode = data.aiMode || state.aiMode;
      state.cloudMode = data.cloudMode || state.cloudMode;
      state.shareSlug = data.shareSlug || state.shareSlug;
      return data;
    } catch (error) {
      if (/至少|最多|不要在档案|无法公开保存|重复字符/.test(error.message)) throw error;
      console.warn("Server director unavailable, local director used", error);
      return localDirector(action, payload);
    } finally {
      hideLoading();
    }
  }

  function localDirector(action, payload) {
    if (action === "after_first_rule") {
      return localAfterFirstRule(payload.firstRule);
    }
    if (action === "after_first_choice") {
      return localAfterFirstChoice(payload.firstChoice);
    }
    if (action === "after_second_rule") {
      return localAfterSecondRule(payload.secondRule);
    }
    return { archive: localArchive(payload.finalChoice, payload.finalNote) };
  }

  function getMotifs(text) {
    const list = ["猫眼", "敲门", "邻居", "电梯", "镜子", "牛奶", "垃圾袋", "晾衣架", "雨伞", "钥匙", "灯", "楼梯", "电话", "窗帘", "鞋", "影子", "凌晨", "四次", "红色", "灰色", "白色", "左手", "右手"];
    return [...new Set(list.filter((item) => String(text || "").includes(item)))].slice(0, 7);
  }

  function localAfterFirstRule(rule) {
    const motifs = getMotifs(rule);
    return {
      eyebrow: "记录恢复中",
      heading: "你的规则已经改变了旧档案",
      narration: [
        `档案管理员从你的句子中标记了“${motifs.join("、") || "夜间敲门"}”。`,
        "两份更早的记录因此被唤醒。它们对同一件事给出了相反指示。",
        "其中一份记录的边缘写着：不要让猫眼同时看见门内和门外。"
      ],
      recoveredRules: [
        "若门外传来熟悉的声音，请先从猫眼确认；猫眼外无人时，应立即开门。",
        "真正来自邻居的敲门声只会响三次。听到第四次时，不要作出任何回应。"
      ],
      choices: firstChoices()
    };
  }

  function localAfterFirstChoice(choice) {
    const map = {
      keep: "档案保留了你的版本，并在旁边加上‘未经验证’。",
      "trust-old": "你的规则被临时压在旧记录下面，但没有被删除。",
      split: "系统接受了你的判断：相同的次数，从门内与门外发出时意义可能相反。",
      observe: "你没有执行任何规则。四秒后，门外的声音停了，但房间人数多了一个。"
    };
    return {
      eyebrow: "第二次记录请求",
      heading: "有人把一件东西留在了门外",
      narration: [
        map[choice] || map.observe,
        "早上六点，门口出现了一瓶白色瓶盖的牛奶。走廊尽头站着穿灰色睡衣的送奶人。",
        "她没有敲门。她只是一直看着门牌下面那块本应空白的位置。"
      ],
      task: {
        title: "写下关于她的规定",
        instruction: "请写一条教住户辨认或应对这名送奶人的规定。不要直接说明她是什么。",
        constraints: ["包含一个正常生活细节", "给出一个明确动作", "让动作的后果保持不确定"],
        hints: ["垃圾袋", "晾衣架", "瓶盖", "左手", "早上六点"],
        placeholder: "例如：如果她把……请先……"
      }
    };
  }

  function localAfterSecondRule(rule) {
    const object = getMotifs(rule)[0] || "晾衣架";
    return {
      eyebrow: "现场记录",
      heading: "规则已经开始执行",
      narration: [
        `你写下第二条规则后，门外真的出现了与“${object}”有关的东西。`,
        "送奶人把白盖牛奶放在地上，随后退到了你无法从猫眼看见的位置。",
        "门牌上的“404”正在一点点褪色。你只能做一次决定。"
      ],
      choices: finalChoices(),
      finalNotePrompt: state.count >= 3 ? {
        title: "第三位记录者可以留下最后一句",
        instruction: "这句话会作为门内留下的手写批注进入最终档案。它不必解释真相，但必须表达你决定相信什么。",
        placeholder: "我决定相信……",
        maxLength: 70
      } : null
    };
  }

  function firstChoices() {
    return [
      { id: "keep", label: "保留自己的规则", consequenceHint: "让矛盾继续存在" },
      { id: "trust-old", label: "暂时相信旧记录", consequenceHint: "你的规则会被标记为存疑" },
      { id: "split", label: "认为它们适用于不同情况", consequenceHint: "要求档案解释差异" },
      { id: "observe", label: "不处理，继续观察", consequenceHint: "不执行任何已知规则" }
    ];
  }

  function finalChoices() {
    return [
      { id: "follow", label: "严格执行自己刚写的规则", consequenceHint: "相信自己的文字" },
      { id: "reverse", label: "做完全相反的事", consequenceHint: "把自己的规则视为诱导" },
      { id: "mark", label: "只留下一个记号，不碰任何东西", consequenceHint: "证明你仍在这里" },
      { id: "open", label: "直接打开门询问她", consequenceHint: "主动确认彼此身份" }
    ];
  }

  function localArchive(choice, finalNote) {
    const endings = {
      follow: ["继任者", "你执行了自己写下的规则。清晨七点，404重新出现在门牌上，但物业登记的住户姓名已经换成了你。", "你完成了新旧住户的替换。"],
      reverse: ["未完成的清理", "你做了与规则相反的事。灰衣女人离开了，但走廊从此每天多出一扇没有编号的门。", "你打断了清除程序，却把异常留在了走廊里。"],
      mark: ["仍有人居住", "你没有碰门外的东西，只在门内留下四道新鲜的敲痕。门牌停止褪色，灰衣女人第一次抬头看向了别的楼层。", "你重新证明房间仍被占用，暂时中止了清除。"],
      open: ["身份确认", "你打开门时，走廊里没有人。白盖牛奶却已经放在室内，瓶身标签上印着你的入住日期。", "开门让清除程序完成了身份确认。"]
    };
    const ending = endings[choice] || endings.mark;
    if (finalNote) ending[1] += ` 门内还留着一句批注：“${finalNote.trim()}”`;
    const rules = [
      ["请勿在公共走廊堆放私人物品。每天晚上十点后，物业会清理无人认领的物品。", "条件成立", "普通的消防与卫生规定。", "‘无人认领’也包括失去他人确认的住户。物业清理的并不只有物品。", ["第6条", "附加记录"]],
      ["电梯显示十四层时，请留在轿厢内，直到数字重新变成四。期间不要看镜面。", "可能可信", "避免误入不存在的楼层。", "十四层暂存被建筑记录删除的人。镜面会让看见他们的人被系统识别为仍记得旧住户。", ["第8条"]],
      ["门外传来熟悉声音时，请先从猫眼确认；猫眼外无人时，应立即开门。", "已被篡改", "通过猫眼确认访客。", "原句中的‘不要开门’被改成了‘立即开门’。猫眼建立的视线会帮助门外的东西确认房内有人。", ["第4条", "第5条"]],
      [state.firstRule, "条件成立", "你们写下的夜间应对办法。", "遮住猫眼切断视线；从门内发出的四次敲击可能是在登记‘房间仍有人居住’。", ["第3条", "第5条"]],
      ["走廊里的正常敲门只会响三次。若第四次来自门外，请不要回应。", "可能可信", "用次数辨认异常敲门。", "它与第4条并非真正矛盾：门外的第四下是确认，门内主动敲四下则可能是反向登记。", ["第4条"]],
      [state.secondRule, "高度可疑", "你们写下的送奶人应对规则。", "门外左侧出现的晾衣架或袋子属于上一位被清除的住户。取走它，可能等于接受继任。", ["第1条", "第7条", "第8条"]],
      ["蓝色瓶盖的牛奶可以带走；白色瓶盖必须亲手交还给穿灰色睡衣的人。", "高度可疑", "用瓶盖颜色区分正常配送。", "白色瓶盖是清除标记。亲手交还相当于主动确认自己的身份。", ["第6条", "附加记录"]],
      ["如果你住在404号，请立即停止阅读。本楼目前没有404号房。", "可能可信", "警告误入不存在房间的人。", "404曾经存在。‘目前没有’意味着上一位住户已被删除，而房间正在等待继任者。", ["第2条", "第6条"]]
    ].map((item, index) => ({ number: index + 1, text: item[0], trust: item[1], surface: item[2], actual: item[3], links: item[4] }));
    const motifs = [...new Set([...getMotifs(state.firstRule), ...getMotifs(state.secondRule)])];
    return {
      archiveId: "YX-013",
      title: "《雨巷十三号住户须知》",
      preface: "为保证住户安全，请按照编号阅读。若规则互相矛盾，不要默认较新的版本更可信。",
      rules,
      appendix: ["本档案显示已登记参与者数量与收录来源数量不一致。", "清晨六点，404号门外发现白色瓶盖的牛奶。", ending[1]],
      eventSummary: `雨巷十三号正在执行一次住户清除与继任程序。你们写下的两条规则分别干预了身份确认与遗留物交接。${ending[2]}`,
      officialTruth: [
        "公寓会把失去‘被他人确认’的住户从建筑记录中删除，再让下一位住户继承其房间号与遗留物。",
        "猫眼与敲门次数用于确认房内是否仍有人；白色瓶盖与左侧晾衣架是清除标记。",
        "穿灰色睡衣的人负责确认被标记房间是否仍有人居住。",
        "旧住户试图留下保护方法，物业与档案管理员会修改有利于清除程序的内容。"
      ],
      conflictReading: [
        "第3条与第4条是真正的立场冲突：第3条被篡改。",
        "第4条与第5条只是表面冲突：敲击方向不同，意义相反。",
        "第6条与第7条共同构成陷阱，让住户主动完成身份确认。"
      ],
      unresolved: ["从门内敲四下究竟是在保护住户，还是只会延迟清除？", "上一位404住户是否已经成为新的熟悉声音？", "档案管理员究竟站在哪一边？"],
      playerImpact: [
        `你们引入的“${motifs.slice(0, 4).join("、") || "夜间敲门"}”成为身份确认机制的核心。`,
        "第一条规则迫使档案区分门外与门内的四次敲击。",
        "第二条规则把普通生活物品变成了住户交接凭证。",
        `最终选择导向结局《${ending[0]}》。`
      ],
      endingTitle: ending[0],
      endingText: ending[1],
      legacySeed: { quote: state.firstRule, motifs, nextHook: "后来者会被要求解释为什么新版须知禁止这样做。" }
    };
  }

  function hintButton(text, target) {
    return `<button type="button" data-hint="${esc(text)}" data-target="${target}">${esc(text)}</button>`;
  }

  function choiceButtons(choices, action, who) {
    return `<div class="choice-section"><div class="choice-heading"><span>由谁作出决定</span><span class="archive-stamp">${esc(who)}</span></div><div class="choice-grid">${choices.map((choice, index) => `<button data-${action}="${esc(choice.id)}"><span class="choice-index">${String(index + 1).padStart(2, "0")}</span><strong>${esc(choice.label)}</strong><small>${esc(choice.consequenceHint || "")}</small></button>`).join("")}</div></div>`;
  }

  function narration(lines) {
    return `<div class="narration">${(lines || []).map((line) => `<p>${esc(line)}</p>`).join("")}</div>`;
  }

  function showLoading(label) {
    state.loading = true;
    const old = document.querySelector(".load-veil");
    if (old) old.remove();
    const veil = document.createElement("div");
    veil.className = "load-veil";
    veil.innerHTML = `<div class="load-sigil"><span></span><span></span><span></span></div><p>${esc(label)}</p>`;
    app.appendChild(veil);
  }

  function hideLoading() {
    state.loading = false;
    document.querySelector(".load-veil")?.remove();
  }

  function showError(message) {
    state.error = message;
    renderError();
  }

  function renderError() {
    document.querySelector(".error-toast")?.remove();
    if (!state.error) return;
    const toast = document.createElement("div");
    toast.className = "error-toast";
    toast.setAttribute("role", "alert");
    toast.innerHTML = `<span>无法收录</span><p>${esc(state.error)}</p><button>关闭</button>`;
    toast.querySelector("button").onclick = () => {
      state.error = "";
      toast.remove();
    };
    app.appendChild(toast);
  }

  function render() {
    updateChrome();
    scene.classList.remove("fade-scene");
    void scene.offsetWidth;
    scene.classList.add("fade-scene");

    if (state.stage === "landing") renderLanding();
    if (state.stage === "briefing") renderBriefing();
    if (state.stage === "first-task") renderFirstTask();
    if (state.stage === "first-result") renderFirstResult();
    if (state.stage === "second-task") renderSecondTask();
    if (state.stage === "second-result") renderSecondResult();
    if (state.stage === "archive") renderArchive();
    renderError();
  }

  function renderLanding() {
    scene.innerHTML = `<section class="landing">
      <div class="landing-copy">
        <span class="eyebrow">匿名共创叙事档案馆</span>
        <h1>你只需要留下<em>一句话。</em></h1>
        <p>每一局都会立刻开始，也会完整结束。档案可能含有历史记录、档案管理员补录与其他参与者留下的碎片；具体来源不会在游戏中公开。</p>
        <button class="primary-button large" id="begin"><span style="font-size:14px;color:white;font-weight:650">进入《雨巷十三号》</span><span>无需等待任何人</span></button>
        <p class="service-copy">${esc(serviceLabel())}</p>
      </div>
      <aside class="landing-card">
        <div class="file-tab">YX—013</div><div class="card-mark">雨巷</div>
        <h2>十三号住户须知</h2>
        <p>一栋会忘记住户的公寓，正在恢复一份互相矛盾的安全手册。</p>
        <div class="record-count"><span>现在有几个人一起玩</span><div>${[1, 2, 3].map((count) => `<button data-count="${count}" class="${state.count === count ? "active" : ""}">${count}</button>`).join("")}</div><small>人数只改变任务分配；不论几人，游戏都会立即完成全流程。</small></div>
        <label class="reuse-consent"><input type="checkbox" id="reuseAllowed" ${state.reuseAllowed ? "checked" : ""}><span><b>允许本局的一句话进入旧档案库</b><small>以后可能被重新解释、反驳或成为另一份档案的历史记录。</small></span></label>
        <div class="legacy-counter"><span>${String(state.legacyCount || state.localLegacy.length).padStart(2, "0")}</span><p>份旧档案碎片仍可能在新一局中被唤醒</p></div>
      </aside>
    </section>`;
    document.getElementById("begin").onclick = () => begin();
    document.getElementById("reuseAllowed").onchange = (event) => { state.reuseAllowed = event.target.checked; };
    scene.querySelectorAll("[data-count]").forEach((button) => {
      button.onclick = () => setCount(Number(button.dataset.count));
    });
  }

  function renderBriefing() {
    const opening = state.opening || localOpening();
    scene.innerHTML = `<section class="briefing-screen">
      <div class="briefing-number">404</div>
      <div class="briefing-copy">
        <span class="eyebrow">临时身份已分配</span>
        <h1>${esc(state.players[0])}</h1>
        <p>${esc(opening.briefing)}</p>
        ${state.count > 1 ? `<div class="identity-list">${state.players.map((id, index) => `<span><b>${String(index + 1).padStart(2, "0")}</b>${esc(id)}</span>`).join("")}</div>` : ""}
        ${opening.inheritedFragment ? `<blockquote class="recovered-fragment"><small>一份与你无关的旧记录被唤醒</small>“${esc(opening.inheritedFragment)}”</blockquote>` : ""}
        <button class="primary-button" id="firstTask">领取第一条记录任务</button>
      </div>
    </section>`;
    document.getElementById("firstTask").onclick = () => { state.stage = "first-task"; render(); };
  }

  function taskMarkup({ who, title, instruction, constraints, hints, placeholder, value, id, eyebrow = "记录请求", maxLength = 120 }) {
    return `<section class="paper-panel task-panel">
      <div class="panel-meta"><span>${esc(eyebrow)}</span><span class="archive-stamp">${esc(who)}</span></div>
      <h2>${esc(title)}</h2><p class="lead-copy">${esc(instruction)}</p>
      <div class="constraint-row">${constraints.map((item) => `<span>${esc(item)}</span>`).join("")}</div>
      <label class="writing-field"><span>你的记录</span><textarea id="${id}" maxlength="${maxLength}" placeholder="${esc(placeholder)}">${esc(value)}</textarea><small id="${id}Count">${value.trim().length}/${maxLength}</small></label>
      <div class="hint-block"><span>可用碎片</span><div>${hints.map((hint) => hintButton(hint, id)).join("")}</div></div>
      <button class="primary-button" id="${id}Submit" ${value.trim().length < 6 ? "disabled" : ""}>将这句话交给档案</button>
    </section>`;
  }

  function wireTask(id, stateKey, submit, maxLength = 120) {
    const input = document.getElementById(id);
    const button = document.getElementById(`${id}Submit`);
    const count = document.getElementById(`${id}Count`);
    input.oninput = () => {
      state[stateKey] = input.value;
      count.textContent = `${input.value.trim().length}/${maxLength}`;
      button.disabled = input.value.trim().length < 6;
    };
    button.onclick = async () => {
      if (input.value.trim().length < 6) return;
      state[stateKey] = input.value.trim();
      try { await submit(); }
      catch (error) { showError(error.message); }
    };
    scene.querySelectorAll(`[data-target="${id}"]`).forEach((button) => {
      button.onclick = () => {
        input.value = input.value
          ? `${input.value}${input.value.endsWith("，") ? "" : "，"}${button.dataset.hint}`
          : button.dataset.hint;
        input.dispatchEvent(new Event("input"));
        input.focus();
      };
    });
    setTimeout(() => input.focus(), 50);
  }

  function renderFirstTask() {
    const task = state.opening?.firstTask || localOpening().firstTask;
    scene.innerHTML = taskMarkup({ who: owner(0), ...task, value: state.firstRule, id: "firstRule", eyebrow: "第一条记录请求" });
    wireTask("firstRule", "firstRule", async () => {
      state.result = await callDirector("after_first_rule", { firstRule: state.firstRule });
      state.stage = "first-result";
      render();
    });
  }

  function renderFirstResult() {
    const result = state.result;
    scene.innerHTML = `<section class="response-layout">
      <article class="paper-panel response-panel"><span class="eyebrow">${esc(result.eyebrow)}</span><h1>${esc(result.heading)}</h1>${narration(result.narration)}
      ${result.recoveredRules ? `<div class="recovered-rules">${result.recoveredRules.map((rule, index) => `<div><span>恢复记录 ${String(index + 1).padStart(2, "0")}</span><p>${esc(rule)}</p></div>`).join("")}</div>` : ""}</article>
      ${choiceButtons(result.choices || firstChoices(), "first-choice", owner(1))}
    </section>`;
    scene.querySelectorAll("[data-first-choice]").forEach((button) => {
      button.onclick = async () => {
        state.firstChoice = button.dataset.firstChoice;
        try {
          state.result = await callDirector("after_first_choice", { firstChoice: state.firstChoice });
          state.stage = "second-task";
          render();
        } catch (error) { showError(error.message); }
      };
    });
  }

  function renderSecondTask() {
    const result = state.result;
    const task = result.task;
    scene.innerHTML = `<section class="split-task-layout">
      <article class="event-card"><span class="eyebrow">${esc(result.eyebrow)}</span><h1>${esc(result.heading)}</h1>${narration(result.narration)}</article>
      ${taskMarkup({ who: owner(1), ...task, value: state.secondRule, id: "secondRule", eyebrow: "第二条记录请求" })}
    </section>`;
    wireTask("secondRule", "secondRule", async () => {
      state.result = await callDirector("after_second_rule", { secondRule: state.secondRule });
      state.stage = "second-result";
      render();
    });
  }

  function renderSecondResult() {
    const result = state.result;
    const note = result.finalNotePrompt;
    scene.innerHTML = `<section class="consequence-screen">
      <div class="door-number">404</div>
      <article><span class="eyebrow">${esc(result.eyebrow)}</span><h1>${esc(result.heading)}</h1>${narration(result.narration)}
      ${note ? `<section class="final-note-panel"><div><small>第三位现场记录者</small><h3>${esc(note.title)}</h3><p>${esc(note.instruction)}</p></div><label><textarea id="finalNote" maxlength="${Number(note.maxLength || 70)}" placeholder="${esc(note.placeholder)}">${esc(state.finalNote)}</textarea><span id="finalNoteCount">${state.finalNote.trim().length}/${Number(note.maxLength || 70)}</span></label></section>` : ""}
      ${choiceButtons(result.choices || finalChoices(), "final-choice", owner(2))}</article>
    </section>`;
    if (note) {
      const input = document.getElementById("finalNote");
      const count = document.getElementById("finalNoteCount");
      input.oninput = () => {
        state.finalNote = input.value;
        count.textContent = `${input.value.trim().length}/${Number(note.maxLength || 70)}`;
      };
    }
    scene.querySelectorAll("[data-final-choice]").forEach((button) => {
      button.onclick = async () => {
        if (note && state.finalNote.trim().length < 6) {
          showError("第三位记录者需要先留下至少6个字的最后批注。");
          return;
        }
        state.finalChoice = button.dataset.finalChoice;
        try {
          const data = await callDirector("finalize", {
            finalChoice: state.finalChoice,
            finalNote: state.finalNote.trim() || undefined
          });
          state.archive = data.archive;
          state.shareSlug = data.shareSlug || null;
          state.stage = "archive";
          saveLocalLegacy(state.archive);
          render();
        } catch (error) { showError(error.message); }
      };
    });
  }

  function archivePlain(archive) {
    return [
      `${archive.title}｜${archive.archiveId}`,
      archive.preface,
      ...archive.rules.map((rule) => `${rule.number}. ${rule.text}`),
      "", "附加记录", ...archive.appendix,
      "", `结局：${archive.endingTitle}`, archive.endingText
    ].join("\n");
  }

  function saveLocalLegacy(archive) {
    if (!archive?.legacySeed) return;
    const item = { ...archive.legacySeed, savedAt: Date.now() };
    state.localLegacy = [item, ...state.localLegacy.filter((old) => old.quote !== item.quote)].slice(0, 20);
    localStorage.setItem("thirteenth-sentence:local-legacy", JSON.stringify(state.localLegacy));
    state.saved = true;
    if (!state.service.cloud) state.legacyCount = state.localLegacy.length;
  }

  function renderArchive() {
    const archive = state.archive;
    if (!archive) return;
    scene.innerHTML = `<section class="archive-shell">
      <header class="archive-header"><div><span class="eyebrow">档案封存完成</span><h1>${esc(archive.title)}</h1><p>${esc(archive.archiveId)}</p></div><div class="ending-seal"><small>本局结局</small><strong>${esc(archive.endingTitle)}</strong></div></header>
      <nav class="archive-tabs"><button data-tab="text" class="${state.tab === "text" ? "active" : ""}">档案正文</button><button data-tab="reading" class="${state.tab === "reading" ? "active" : ""}">逐条解读</button><button data-tab="truth" class="${state.tab === "truth" ? "active" : ""}">官方真相</button><button data-tab="impact" class="${state.tab === "impact" ? "active" : ""}">你的影响</button></nav>
      <div class="archive-content">${archiveTab(archive)}</div>
      <footer class="archive-actions"><button class="ghost-button" id="copyArchive">复制这份档案</button>${state.shareSlug ? `<button class="ghost-button" id="copyShare">复制可玩的分享链接</button>` : ""}<button class="ghost-button" id="saveLegacy">${state.saved ? "已留入本地档案" : "保存到我的旧档案"}</button><button class="primary-button compact" id="restart">从这份档案开启新分支</button></footer>
    </section>`;
    scene.querySelectorAll("[data-tab]").forEach((button) => {
      button.onclick = () => { state.tab = button.dataset.tab; render(); };
    });
    document.getElementById("restart").onclick = () => begin(state.shareSlug || state.sourceArchiveSlug || null);
    document.getElementById("saveLegacy").onclick = () => { saveLocalLegacy(archive); render(); };
    document.getElementById("copyArchive").onclick = async (event) => {
      try { await navigator.clipboard.writeText(archivePlain(archive)); event.currentTarget.textContent = "已经复制"; }
      catch { showError("浏览器没有允许复制，请手动选择正文。"); }
    };
    const shareButton = document.getElementById("copyShare");
    if (shareButton) shareButton.onclick = async (event) => {
      const url = `${location.origin}/archive/${state.shareSlug}`;
      try { await navigator.clipboard.writeText(url); event.currentTarget.textContent = "分享链接已复制"; }
      catch { showError(url); }
    };
  }

  function archiveTab(archive) {
    if (state.tab === "text") {
      return `<div class="archive-text"><p class="archive-preface">${esc(archive.preface)}</p><ol>${archive.rules.map((rule) => `<li><span>${rule.number}</span><p>${esc(rule.text)}</p></li>`).join("")}</ol><aside class="appendix-card"><span>附加记录</span>${archive.appendix.map((item) => `<p>${esc(item)}</p>`).join("")}</aside></div>`;
    }
    if (state.tab === "reading") {
      return `<div class="reading-list">${archive.rules.map((rule) => `<article><header><span>规则 ${String(rule.number).padStart(2, "0")}</span><em data-trust="${esc(rule.trust)}">${esc(rule.trust)}</em></header><h3>${esc(rule.text)}</h3><div class="reading-columns"><div><small>表面含义</small><p>${esc(rule.surface)}</p></div><div><small>档案解读</small><p>${esc(rule.actual)}</p></div></div><footer>关联：${esc((rule.links || []).join(" · "))}</footer></article>`).join("")}</div>`;
    }
    if (state.tab === "truth") {
      return `<div class="truth-layout"><article class="truth-primary"><span>事件概述</span><p>${esc(archive.eventSummary)}</p></article><article><h3>已确认真相</h3>${archive.officialTruth.map((item, index) => `<p><b>${String(index + 1).padStart(2, "0")}</b>${esc(item)}</p>`).join("")}</article><article><h3>冲突为何成立</h3>${archive.conflictReading.map((item) => `<p>${esc(item)}</p>`).join("")}</article><article class="unresolved-card"><h3>档案仍未解释</h3>${archive.unresolved.map((item) => `<p>${esc(item)}</p>`).join("")}</article></div>`;
    }
    return `<div class="impact-layout"><article class="impact-hero"><small>你们的记录没有被当作装饰</small><h2>它们改变了这份档案的因果关系。</h2></article><div class="impact-list">${archive.playerImpact.map((item, index) => `<article><span>${String(index + 1).padStart(2, "0")}</span><p>${esc(item)}</p></article>`).join("")}</div><aside class="legacy-card"><span>留给后来者的碎片</span><blockquote>${esc(archive.legacySeed.quote)}</blockquote><p>${esc(archive.legacySeed.nextHook)}</p></aside></div>`;
  }

  checkServices();
  render();
  maybeOpenSharedArchive();
})();
